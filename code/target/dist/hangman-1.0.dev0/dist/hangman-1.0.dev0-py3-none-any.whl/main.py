from hangman import play_game

def main():
    play_game()


if __name__ == "__main__":
    main()



